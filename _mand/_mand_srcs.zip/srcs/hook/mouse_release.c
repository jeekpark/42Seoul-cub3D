/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mouse_release.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jeekpark <jeekpark@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/21 00:02:50 by jeekpark          #+#    #+#             */
/*   Updated: 2023/09/21 14:52:04 by jeekpark         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/cub3d.h"

int	mouse_release(int keycode, int x, int y, t_game *game)
{
	(void)x;
	(void)y;
	(void)game;
	(void)keycode;
	return (0);
}
